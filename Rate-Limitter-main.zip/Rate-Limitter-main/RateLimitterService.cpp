#include <bits/stdc++.h>
using namespace std;

// ============================================================
// RateLimiter Interface
// ============================================================

class RateLimiter {
public:
    virtual bool allowRequest(const string &key) = 0;

    virtual ~RateLimiter() = default;
};


// ============================================================
// 1. Token Bucket
// ============================================================

class TokenBucket : public RateLimiter {

    struct UserState {
        double tokens;
        chrono::steady_clock::time_point lastRefill;

        UserState(double capacity)
            : tokens(capacity),
              lastRefill(chrono::steady_clock::now()) {}
    };

    double capacity;
    double refillRate;

    unordered_map<string, UserState> users;
    mutex mtx;

public:

    TokenBucket(double capacity, double refillRate)
        : capacity(capacity),
          refillRate(refillRate) {
    }

    bool allowRequest(const string &key) override {

        lock_guard<mutex> lock(mtx);

        auto [it, inserted] =
            users.try_emplace(key, capacity);

        UserState &state = it->second;

        auto now = chrono::steady_clock::now();

        double elapsed =
            chrono::duration<double>(
                now - state.lastRefill
            ).count();

        state.tokens = min(
            capacity,
            state.tokens + elapsed * refillRate
        );

        state.lastRefill = now;

        if (state.tokens >= 1.0) {
            state.tokens--;
            return true;
        }

        return false;
    }
};


// ============================================================
// 2. Fixed Window
// ============================================================

class FixedWindow : public RateLimiter {

    struct UserState {
        long long windowStart;
        int count;

        UserState(long long start)
            : windowStart(start),
              count(0) {}
    };

    int limit;
    long long windowSizeMs;

    unordered_map<string, UserState> users;
    mutex mtx;

    long long currentTime() {

        return chrono::duration_cast<
            chrono::milliseconds
        >(
            chrono::steady_clock::now().time_since_epoch()
        ).count();
    }

public:

    FixedWindow(int limit, long long windowSizeMs)
        : limit(limit),
          windowSizeMs(windowSizeMs) {
    }

    bool allowRequest(const string &key) override {

        lock_guard<mutex> lock(mtx);

        long long now = currentTime();

        auto [it, inserted] =
            users.try_emplace(key, now);

        UserState &state = it->second;

        if (now - state.windowStart >= windowSizeMs) {

            state.windowStart = now;
            state.count = 0;
        }

        if (state.count < limit) {

            state.count++;
            return true;
        }

        return false;
    }
};


// ============================================================
// 3. Sliding Window Counter
// ============================================================

class SlidingWindowCounter : public RateLimiter {

    struct UserState {
        long long windowStart;

        int previousCount;
        int currentCount;

        UserState(long long start)
            : windowStart(start),
              previousCount(0),
              currentCount(0) {}
    };

    int limit;
    long long windowSizeMs;

    unordered_map<string, UserState> users;
    mutex mtx;

    long long currentTime() {

        return chrono::duration_cast<
            chrono::milliseconds
        >(
            chrono::steady_clock::now().time_since_epoch()
        ).count();
    }

public:

    SlidingWindowCounter(
        int limit,
        long long windowSizeMs
    )
        : limit(limit),
          windowSizeMs(windowSizeMs) {
    }

    bool allowRequest(const string &key) override {

        lock_guard<mutex> lock(mtx);

        long long current = currentTime();

        auto [it, inserted] =
            users.try_emplace(key, current);

        UserState &state = it->second;

        long long elapsed =
            current - state.windowStart;

        if (elapsed >= windowSizeMs) {

            state.previousCount =
                state.currentCount;

            state.currentCount = 0;

            state.windowStart = current;

            elapsed = 0;
        }

        double overlap =
            1.0 -
            static_cast<double>(elapsed)
            / windowSizeMs;

        double estimatedRequests =
            state.currentCount +
            state.previousCount * overlap;

        if (estimatedRequests >= limit)
            return false;

        state.currentCount++;

        return true;
    }
};


// ============================================================
// 4. Sliding Window Log
// ============================================================

class SlidingWindowLog : public RateLimiter {

    struct UserState {
        deque<long long> timestamps;
    };

    int limit;
    long long windowSizeMs;

    unordered_map<string, UserState> users;
    mutex mtx;

    long long currentTime() {

        return chrono::duration_cast<
            chrono::milliseconds
        >(
            chrono::steady_clock::now().time_since_epoch()
        ).count();
    }

public:

    SlidingWindowLog(
        int limit,
        long long windowSizeMs
    )
        : limit(limit),
          windowSizeMs(windowSizeMs) {
    }

    bool allowRequest(const string &key) override {

        lock_guard<mutex> lock(mtx);

        long long now = currentTime();

        auto [it, inserted] =
            users.try_emplace(key);

        UserState &state = it->second;

        while (
            !state.timestamps.empty() &&
            state.timestamps.front()
                <= now - windowSizeMs
        ) {
            state.timestamps.pop_front();
        }

        if (state.timestamps.size() >=
            static_cast<size_t>(limit)) {

            return false;
        }

        state.timestamps.push_back(now);

        return true;
    }
};


// ============================================================
// Factory Pattern
// ============================================================

enum class Algorithm {
    TOKEN_BUCKET = 1,
    FIXED_WINDOW = 2,
    SLIDING_WINDOW_COUNTER = 3,
    SLIDING_WINDOW_LOG = 4
};


class RateLimiterFactory {

public:

    static unique_ptr<RateLimiter> create(
        Algorithm algorithm,
        int limit,
        long long windowSizeMs,
        double refillRate = 0
    ) {

        switch (algorithm) {

            case Algorithm::TOKEN_BUCKET:
                return make_unique<TokenBucket>(
                    limit,
                    refillRate
                );

            case Algorithm::FIXED_WINDOW:
                return make_unique<FixedWindow>(
                    limit,
                    windowSizeMs
                );

            case Algorithm::SLIDING_WINDOW_COUNTER:
                return make_unique<SlidingWindowCounter>(
                    limit,
                    windowSizeMs
                );

            case Algorithm::SLIDING_WINDOW_LOG:
                return make_unique<SlidingWindowLog>(
                    limit,
                    windowSizeMs
                );
        }

        return nullptr;
    }
};


// ============================================================
// RateLimiter Service
// ============================================================

class RateLimiterService {

    unique_ptr<RateLimiter> limiter;

public:

    RateLimiterService(
        unique_ptr<RateLimiter> limiter
    )
        : limiter(move(limiter)) {
    }

    bool allowRequest(const string &key) {

        return limiter->allowRequest(key);
    }
};


// ============================================================
// Concurrent Test
// ============================================================

void concurrentTest(RateLimiterService &service) {

    cout << "\n===== Concurrent Test =====\n";

    vector<string> users = {
        "user123",
        "user456",
        "user789"
    };

    vector<thread> threads;

    mutex outputMutex;

    for (const string &user : users) {

        threads.emplace_back(
            [&service, &outputMutex, user]() {

                for (int i = 0; i < 10; i++) {

                    bool allowed =
                        service.allowRequest(user);

                    lock_guard<mutex> lock(outputMutex);

                    cout
                        << this_thread::get_id()
                        << " | "
                        << user
                        << " | "
                        << (allowed
                            ? "ALLOWED"
                            : "REJECTED")
                        << '\n';

                    this_thread::sleep_for(
                        chrono::milliseconds(50)
                    );
                }
            }
        );
    }

    for (auto &thread : threads) {

        thread.join();
    }

    cout << "===== Test Complete =====\n";
}


// ============================================================
// Main
// ============================================================

int main() {

    cout << "==============================\n";
    cout << "     Rate Limiter Service\n";
    cout << "==============================\n\n";

    cout << "Select algorithm:\n";
    cout << "1. Token Bucket\n";
    cout << "2. Fixed Window\n";
    cout << "3. Sliding Window Counter\n";
    cout << "4. Sliding Window Log\n";

    int choice;

    cout << "\nEnter choice: ";
    cin >> choice;

    if (choice < 1 || choice > 4) {

        cout << "Invalid choice.\n";
        return 1;
    }

    int limit;

    cout << "Enter request limit: ";
    cin >> limit;

    if (limit <= 0) {

        cout << "Limit must be positive.\n";
        return 1;
    }

    long long windowSizeMs = 10000;

    double refillRate = 0;

    Algorithm algorithm =
        static_cast<Algorithm>(choice);

    if (algorithm == Algorithm::TOKEN_BUCKET) {

        cout << "Enter refill rate (tokens/sec): ";
        cin >> refillRate;

        if (refillRate <= 0) {

            cout << "Refill rate must be positive.\n";
            return 1;
        }

    } else {

        cout << "Enter window size (milliseconds): ";
        cin >> windowSizeMs;

        if (windowSizeMs <= 0) {

            cout << "Window size must be positive.\n";
            return 1;
        }
    }

    auto limiter =
        RateLimiterFactory::create(
            algorithm,
            limit,
            windowSizeMs,
            refillRate
        );

    RateLimiterService service(
        move(limiter)
    );


    // --------------------------------------------------------
    // Concurrent multi-user test
    // --------------------------------------------------------

    concurrentTest(service);


    // --------------------------------------------------------
    // Interactive terminal mode
    // --------------------------------------------------------

    cout << "\n===== Interactive Mode =====\n";
    cout << "Enter 'exit' as user ID to stop.\n\n";

    while (true) {

        string user;

        cout << "User ID: ";
        cin >> user;

        if (user == "exit")
            break;

        bool allowed =
            service.allowRequest(user);

        auto now =
            chrono::system_clock::now();

        auto time =
            chrono::system_clock::to_time_t(now);

        cout
            << put_time(
                localtime(&time),
                "%H:%M:%S"
            )
            << " | "
            << user
            << " | "
            << (allowed
                ? "ALLOWED"
                : "REJECTED")
            << '\n';
    }

    return 0;
}