# Rate Limiter Algorithms in C++

This repository contains C++ implementations of four standard rate-limiting algorithms. Rate limiting is a crucial technique used in network services and APIs to throttle traffic, preventing overload and ensuring fair usage.

## Architecture

The project is built around a unified interface and factory pattern:
- **`RateLimiter`**: An abstract base class with a method `allowRequest(const string &key)` where `key` is the user ID.
- **`RateLimiterFactory`**: Uses the Factory design pattern to dynamically instantiate the desired rate-limiting algorithm at runtime based on user selection.
- **`RateLimiterService`**: A wrapper service holding the chosen algorithm, allowing requests to be easily processed.
- **Per-User Tracking & Thread Safety**: Each algorithm maintains its own internal state using an `std::unordered_map<string, UserState>`, mapping specific user IDs to their distinct request histories/token buckets. Concurrency is handled securely via a `std::mutex` so multiple threads can evaluate and modify user states simultaneously without race conditions.

## Implemented Algorithms

1. **Token Bucket (`TokenBucket`)** 
   - **Parameters**: `capacity`, `refillRate` (tokens per second)
   - **How it works**: A bucket holds a maximum number of tokens. It refills gradually based on the elapsed time. Requests are allowed if at least 1 token is available. Allows for short bursts of traffic.

2. **Fixed Window Counter (`FixedWindow`)**
   - **Parameters**: `limit` (max requests), `windowSizeMs` (window duration in ms)
   - **How it works**: Divides time into fixed discrete windows. If the request count in the current window exceeds the limit, requests are rejected until the next time window starts.

3. **Sliding Window Counter (`SlidingWindowCounter`)**
   - **Parameters**: `limit`, `windowSizeMs`
   - **How it works**: A hybrid approach that stores the counter for the previous window and the current window. It estimates the number of requests in the sliding window by dynamically weighting the previous window's count based on the overlap percentage. 

4. **Sliding Window Log (`SlidingWindowLog`)**
   - **Parameters**: `limit`, `windowSizeMs`
   - **How it works**: Keeps a precise `std::deque` of timestamps for every accepted request. Outdated timestamps are evicted. If the queue size exceeds the limit, it rejects the request. Uses more memory but acts as a highly accurate strict sliding window.

## How to Build and Run

The program includes both a built-in concurrent test featuring multiple threads (`user123`, `user456`, `user789`), and an interactive terminal mode allowing you to test limits manually.

Wait for standard tools to compile it:

```bash
# Navigate to the directory
cd "Rate Limitting Algos"

# Compile the code
g++ -O3 RateLimitterService.cpp -o RateLimitterService

# Run the program
./RateLimitterService
```

### Example Usage Flow:

1. **Interactive Setup**: The console prompts you to pick an algorithm (1-4).
2. **Set Parameters**: It prompts for the Request Limit and Window Size (or Refill Rate).
3. **Automated Thread Test**: The program spawns threads simulating multiple users bursting the API simultaneously and prints the thread-safe results.
4. **Interactive Mode**: You can continuously type `user_id` to manually check if they are allowed or rejected. Type `exit` to quit.

```text
==============================
     Rate Limiter Service
==============================

Select algorithm:
1. Token Bucket
...
Enter choice: 1
Enter request limit: 5
Enter refill rate (tokens/sec): 2

===== Concurrent Test =====
14051... | user123 | ALLOWED
14051... | user456 | ALLOWED
...
===== Test Complete =====

===== Interactive Mode =====
Enter 'exit' as user ID to stop.

User ID: user123
12:35:10 | user123 | REJECTED
```
